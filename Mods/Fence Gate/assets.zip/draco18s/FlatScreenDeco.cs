﻿using System;
using UnityEngine;

namespace Assets.draco18s {
	public class FlatScreenDeco :
#if DLL_EXPORT
		ParkitectMod.FlatScreen
#else
		MonoBehaviour
#endif
		{
#if DLL_EXPORT
#else
		public float height;
#endif
	}
}
