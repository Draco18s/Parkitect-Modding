﻿using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

namespace Assets.draco18s {
	public class CurvedBannerDeco :
#if DLL_EXPORT
		ParkitectMod.CurvedBanner
#else
		MonoBehaviour
#endif
		{
#if DLL_EXPORT
#else
		public float height;
#endif

	}
}
