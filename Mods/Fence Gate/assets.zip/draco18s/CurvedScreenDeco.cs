﻿using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

namespace Assets.draco18s {
	public class CurvedScreenDeco :
#if DLL_EXPORT
		ParkitectMod.CurvedScreen
#else
		MonoBehaviour
#endif
		{
#if DLL_EXPORT
#else
		public float height;
#endif

	}
}
